TABLICA OPERACYJNA – logo Array | Willson & Brown i przycisk X

W tym archiwum:
- index.html – aktualny układ tablicy; logo jest osadzone w HTML i dodatkowo dostępne jako plik PNG.
- logo-array-willson-brown.png – plik logo.
- Zmiany w polach i kolorach są zapisywane w localStorage po każdej edycji.
- Przycisk X wykonuje dodatkowy zapis przed próbą zamknięcia aplikacji.

WAŻNE: aby X zamykał natywną aplikację Android:
1. Otwórz w GitHubie plik .github/workflows/build-apk.yml (albo plik workflow, którego używasz do budowania APK).
2. Kliknij ołówek Edit.
3. Znajdź polecenie npm install zawierające @capacitor/core oraz @capacitor/cli.
4. Dopisz do tego samego polecenia: @capacitor/app
   Przykład:
   npm install @capacitor/core @capacitor/cli @capacitor/app
5. Upewnij się, że poniżej nadal wykonywane jest:
   npx cap sync android
6. Zapisz zmiany przyciskiem Commit changes i uruchom ponownie workflow (Actions → Build APK → Re-run jobs).

Jeśli workflow ma osobne polecenie npm install, można zamiast tego dodać osobny krok:
   npm install @capacitor/app
   npx cap sync android

Uwaga: samo window.close() w zwykłej karcie Chrome nie może zamknąć dowolnej karty. Pełne zamknięcie jest dostępne po zbudowaniu APK z natywnym pluginem @capacitor/app.
