TABLICA OPERACYJNA – poprawione logo i przycisk X

Zawartość:
- index.html – aktualna tablica z nowym logo oraz przyciskiem X.
- logo-array-willson-brown.png – przycięty plik logo (logo jest też osadzone w index.html).

WAŻNE – przebudowa APK:
Aby przycisk X naprawdę zamykał aplikację Android (a nie tylko kartę przeglądarki),
w projekcie Capacitor trzeba dodać natywny plugin:
  npm install @capacitor/app
  npx cap sync android

Następnie przebudować APK dotychczasowym workflow GitHub Actions.
Zmiany tablicy są zapisywane w localStorage po każdej edycji; X dodatkowo wymusza zapis przed wyjściem.
