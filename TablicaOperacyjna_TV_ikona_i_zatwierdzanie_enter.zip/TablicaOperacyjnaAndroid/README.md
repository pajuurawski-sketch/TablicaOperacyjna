# Tablica operacyjna – projekt Android

Projekt Android Studio z aplikacją WebView, przeznaczony dla telefonów Android i Android TV (w tym TCL QLED 870). Wbudowuje aktualną tablicę HTML jako zasób lokalny, uruchamia ją bez pasków systemowych i utrzymuje ekran włączony.

## Budowanie APK
1. Otwórz folder `TablicaOperacyjnaAndroid` w Android Studio.
2. Poczekaj na synchronizację Gradle (wymagany Android SDK 35).
3. Wybierz Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

Minimalny Android: 6.0 (API 23). Aplikacja ma zwykły launcher i launcher Android TV.


Wersja 1.3: paleta kolorów jest wymuszenie ukryta we wszystkich edytorach danych; dostępna wyłącznie dla maszyn i statusu formy. Odświeżono ikony etykiet na spójne ikony SVG.
