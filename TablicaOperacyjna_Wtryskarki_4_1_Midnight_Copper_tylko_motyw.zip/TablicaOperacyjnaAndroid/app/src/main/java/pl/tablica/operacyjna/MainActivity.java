package pl.tablica.operacyjna;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    private void immersive() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        web = new WebView(this);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.requestFocus(View.FOCUS_DOWN);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (web != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            int k = event.getKeyCode();
            if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                // Obsługa przycisku Gotowe/strzałki na klawiaturze ekranowej TV.
                web.evaluateJavascript("(function(){var m=document.getElementById('modalBg');if(m&&m.classList.contains('open')){var b=document.getElementById('apply');if(b&&!b.hidden){b.click();return;}}})()", null);
                return true;
            }
            // DPAD_CENTER pozostawiamy systemowi/klawiaturze Android TV.
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @Override protected void onPause() {
        if (web != null) web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'));", null);
        super.onPause();
    }

    @Override protected void onStop() {
        if (web != null) web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'));", null);
        super.onStop();
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("document.getElementById('modalBg').classList.remove('open')", null);
        else super.onBackPressed();
    }
}
